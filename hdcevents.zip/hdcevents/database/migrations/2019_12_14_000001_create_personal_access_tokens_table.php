<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePersonalAccessTokensTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('eventos', function (Blueprint $table) {
            $table->id(); // Coluna de chave primária automática
            $table->string('nome_do_evento');
            $table->date('data_do_evento');
            $table->string('cidade');
            $table->enum('privado_publico', ['privado', 'publico']); // Enum para privado ou público
            $table->text('descricao_do_evento');
            $table->timestamps(); // Colunas de data de criação e atualização automática
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('eventos');
    }
}

