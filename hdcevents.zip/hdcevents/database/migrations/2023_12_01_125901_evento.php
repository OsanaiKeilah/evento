<?php

// database/migrations/xxxx_xx_xx_create_eventos_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Evento extends Migration
{
    public function up()
    {
        Schema::create('eventos', function (Blueprint $table) {
            $table->id();
            $table->string('nome_do_evento');
            $table->date('data_do_evento');
            $table->string('cidade');
            $table->string('privado_ou_publico');
            $table->text('descricao_do_evento');
            
            // Adicionar timestamps diretamente aqui
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('eventos');
    }
}