<?php
// app/Http/Controllers/EventoController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Evento;

class EventoController extends Controller
{
    public function store(Request $request)
    {
        // Validação dos dados do formulário
        $request->validate([
            'nome' => 'required|string|max:255',
            'data' => 'required|date',
            'cidade' => 'required|string|max:255',
            'privacidade' => 'required|in:privado,publico',
            'descricao' => 'required|string',
        ]);
    
        // Criação do evento no banco de dados
        $evento = Evento::create([
            'nome_do_evento' => $request->input('nome'),
            'data_do_evento' => $request->input('data'),
            'cidade' => $request->input('cidade'),
            'privado_ou_publico' => $request->input('privacidade'),
            'descricao_do_evento' => $request->input('descricao'),
        ]);
    
        // Redireciona para alguma página de confirmação ou lista de eventos
        return redirect('/')->with('success', 'Evento criado com sucesso!');
    }
    
    public function exibirEventos()
    {
        $eventos = Evento::all();
        return view('exibirEventos', ['eventos' => $eventos]);
    }
    public function mostrarMensagem(Request $request)
    {
        // Recupera a mensagem de sucesso e a exibe na página
        $mensagem = $request->session()->get('success');
        return view('exibirEventos', ['mensagem' => $mensagem]);
    }
}