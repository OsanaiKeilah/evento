<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
    protected $fillable = [
        'nome_do_evento', 'data_do_evento', 'cidade', 'privado_ou_publico', 'descricao_do_evento',
    ];

    // Desativar timestamps
    public $timestamps = false;
}