<!-- resources/views/criar-evento.blade.php -->

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Criar Evento</title>
    <!-- Adicione os links para os estilos Bootstrap se estiver usando Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Criar Novo Evento</h1>
        <form method="post" action="/criar-evento" class="needs-validation" novalidate>
            @csrf
            <div class="form-group">
                <label for="nome">Nome do Evento:</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Enter email" required>
                <div class="invalid-feedback">
                    Por favor, insira o nome do evento.
                </div>
            </div>

            <div class="form-group">
                <label for="data">Data do Evento:</label>
                <input type="date" class="form-control" id="data" name="data" required>
                <div class="invalid-feedback">
                    Por favor, insira a data do evento.
                </div>
            </div>

            <div class="form-group">
                <label for="cidade">Cidade:</label>
                <input type="text" class="form-control" id="cidade" name="cidade" placeholder="Enter city" required>
                <div class="invalid-feedback">
                    Por favor, insira a cidade do evento.
                </div>
            </div>

            <div class="form-group">
                <label for="privacidade">Privado ou Público:</label>
                <select class="form-control" id="privacidade" name="privacidade" required>
                    <option value="privado">Privado</option>
                    <option value="publico">Público</option>
                </select>
                <div class="invalid-feedback">
                    Por favor, selecione a privacidade do evento.
                </div>
            </div>

            <div class="form-group">
                <label for="descricao">Descrição do Evento:</label>
                <textarea class="form-control" id="descricao" name="descricao" rows="3" required></textarea>
                <div class="invalid-feedback">
                    Por favor, insira uma descrição para o evento.
                </div>
            </div>

            <button type="submit"class="btn btn-dark">Submit</button>
        </form>
        <a href="{{ url('/exibirEventos') }}" class="custom-link">Ver Eventos</a>

    </div>

    <style>
    .custom-link {
        color: black;
        text-align: center;
        display: block; 
        margin-top: 10px; 
    }
    
</style>

    <!-- Adicione os scripts Bootstrap se estiver usando Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Adicione script para ativar validação de formulário Bootstrap -->
    <script>
        // Adicione este script para ativar a validação de formulário Bootstrap
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>
</html>
