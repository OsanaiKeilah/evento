<!-- resources/views/exibirEventos.blade.php -->

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exibir Eventos</title>
    <!-- Adicione os links para os estilos Bootstrap se estiver usando Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Eventos</h1>

        @if(isset($mensagem))
            <div class="alert alert-success" role="alert">
                {{ $mensagem }}
            </div>
        @endif

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nome do Evento</th>
                    <th scope="col">Data do Evento</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Privacidade</th>
                    <th scope="col">Descrição</th>
                </tr>
            </thead>
            <tbody>
                @foreach($eventos as $evento)
                    <tr>
                        <th scope="row">{{ $evento->id }}</th>
                        <td>{{ $evento->nome_do_evento }}</td>
                        <td>{{ $evento->data_do_evento }}</td>
                        <td>{{ $evento->cidade }}</td>
                        <td>{{ $evento->privado_ou_publico }}</td>
                        <td>{{ $evento->descricao_do_evento }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <!-- Adicione os scripts Bootstrap se estiver usando Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
