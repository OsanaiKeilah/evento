<!-- resources/views/exibirEventos.blade.php -->

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exibir Eventos</title>
    <!-- Adicione os links para os estilos Bootstrap se estiver usando Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Eventos</h1>

        <?php if(isset($mensagem)): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e($mensagem); ?>

            </div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nome do Evento</th>
                    <th scope="col">Data do Evento</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Privacidade</th>
                    <th scope="col">Descrição</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($evento->id); ?></th>
                        <td><?php echo e($evento->nome_do_evento); ?></td>
                        <td><?php echo e($evento->data_do_evento); ?></td>
                        <td><?php echo e($evento->cidade); ?></td>
                        <td><?php echo e($evento->privado_ou_publico); ?></td>
                        <td><?php echo e($evento->descricao_do_evento); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Adicione os scripts Bootstrap se estiver usando Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\PC-01\hdcevents\resources\views/exibirEventos.blade.php ENDPATH**/ ?>