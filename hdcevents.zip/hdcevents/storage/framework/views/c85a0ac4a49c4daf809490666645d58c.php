<h1> Página de contato</h1>

<a href="/">Voltar para home</a><?php /**PATH C:\Users\PC-01\hdcevents\resources\views/contact.blade.php ENDPATH**/ ?>