<?php

namespace App\Http\Controllers;

use App\Models\Evento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EventoController extends Controller
{
    public function create(Request $request){
        $nome = $request->input('nome');
        $data = $request->input('data');
        $cidade = $request->input('cidade');
        $privOuPublic = $request->input('privOuPublic');
        $descricao = $request->input('descricao');

        
        DB::table('eventos')->insert([
            'nome' => $nome,
            'data' => $data,
            'cidade' => $cidade,
            'privOuPublic' => $privOuPublic,
            'descricao' =>$descricao
        ]);

        return redirect()->route("feedback");
    
    }

    public function feedback(){

        $evento = Evento::all();

        return view ("feedback", ['evento' => $evento]);
        
    }
}
