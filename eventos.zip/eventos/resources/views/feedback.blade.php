@extends('layout.index')

@section('title', 'Feedback do usuario')

@section ('body')

<div>
    @foreach ($evento as $evento)
    <p> {{ $evento->nome }}</p>
    <p> {{ $evento->data }}</p>
    <p> {{ $evento->cidade }}</p>
    <p> {{ $evento->privOuPublic }}</p>
    <p> {{ $evento->descricao }}</p>
    @endforeach
</div>
