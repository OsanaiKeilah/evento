@extends('layout.index')

@section('title', 'formulario')

@section ('body')

<form action="/create" method="post">
  <h2>Digite as informações do seu evento</h2>
  <input type="text" placeholder="nome" name="nome">
  <input type="text" placeholder="data" name="data">
  <input type="text" placeholder="cidade" name="cidade">
  <select type="text" placeholder="privOuPublic" name="privOuPublic"><option value="privado">privado</option><option value="publico">publico</option></select>
  <input type="text" placeholder="descricao" name="descricao">
  <button>Enviar!</button>
</form>

